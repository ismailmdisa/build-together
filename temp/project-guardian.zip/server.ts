import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import Database from "better-sqlite3";

const db = new Database("guardian.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    id TEXT PRIMARY KEY,
    value TEXT
  );
  CREATE TABLE IF NOT EXISTS blocked_domains (
    domain TEXT PRIMARY KEY,
    category TEXT,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Seed some initial domains if empty
const existing = db.prepare("SELECT count(*) as count FROM blocked_domains").get() as { count: number };
if (existing.count === 0) {
  const initialDomains = [
    ['porn.com', 'Adult'],
    ['xhamster.com', 'Adult'],
    ['pornhub.com', 'Adult'],
    ['xnxx.com', 'Adult'],
    ['xvideos.com', 'Adult'],
    ['redtube.com', 'Adult'],
    ['youporn.com', 'Adult']
  ];
  const insert = db.prepare("INSERT INTO blocked_domains (domain, category) VALUES (?, ?)");
  initialDomains.forEach(d => insert.run(d[0], d[1]));
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/settings", (req, res) => {
    const row = db.prepare("SELECT value FROM settings WHERE id = 'global'").get() as { value: string } | undefined;
    if (row) {
      res.json(JSON.parse(row.value));
    } else {
      res.json({});
    }
  });

  app.post("/api/settings", (req, res) => {
    const settings = JSON.stringify(req.body);
    db.prepare("INSERT OR REPLACE INTO settings (id, value) VALUES ('global', ?)").run(settings);
    res.json({ success: true });
  });

  app.post("/api/alerts", (req, res) => {
    const { type, partnerName, partnerEmail, partnerPhone } = req.body;
    
    console.log(`[ALERT] Sending ${type} alert to ${partnerName} (${partnerEmail} / ${partnerPhone})`);
    
    // Hypothetical SMS/Email sending logic
    // In a real app, you'd use Twilio, SendGrid, etc.
    
    res.json({ 
      success: true, 
      message: `Alert sent to ${partnerName} via ${partnerEmail}${partnerPhone ? ' and ' + partnerPhone : ''}` 
    });
  });

  app.get("/api/blocked-domains", (req, res) => {
    const domains = db.prepare("SELECT * FROM blocked_domains ORDER BY added_at DESC").all();
    res.json(domains);
  });

  app.post("/api/blocked-domains", (req, res) => {
    const { domain, category } = req.body;
    try {
      db.prepare("INSERT INTO blocked_domains (domain, category) VALUES (?, ?)").run(domain, category || 'Adult');
      res.json({ success: true });
    } catch (err) {
      res.status(400).json({ error: "Domain already exists or invalid" });
    }
  });

  app.delete("/api/blocked-domains/:domain", (req, res) => {
    db.prepare("DELETE FROM blocked_domains WHERE domain = ?").run(req.params.domain);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
