import { Shield, EyeOff, Lock, ShieldCheck, Cpu, Network, ShieldAlert, Clock, Check, X, Menu, X as XIcon, Settings, ChevronRight, ChevronLeft, Smartphone, AlertCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import SettingsPanel from './components/SettingsPanel';

export default function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentView, setCurrentView] = useState<'landing' | 'settings' | 'onboarding'>('landing');
  const [onboardingStep, setOnboardingStep] = useState(0);

  // Check if onboarding is needed (simulated for demo)
  useEffect(() => {
    const hasOnboarded = localStorage.getItem('guardian_onboarded');
    if (!hasOnboarded && currentView !== 'onboarding') {
      // We'll let the user click "Get Started" to enter onboarding
    }
  }, [currentView]);

  const completeOnboarding = () => {
    localStorage.setItem('guardian_onboarded', 'true');
    setCurrentView('settings');
  };

  const onboardingSteps = [
    {
      title: "Welcome to Project Guardian",
      description: "Your digital gaze is precious. We're here to help you protect it with advanced, on-device AI technology.",
      icon: <Shield className="w-12 h-12 text-emerald-500" />,
      content: (
        <div className="space-y-4 text-left">
          <div className="flex gap-3 p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
            <ShieldCheck className="w-5 h-5 text-emerald-600 flex-shrink-0" />
            <p className="text-sm text-emerald-800">100% Privacy: All AI analysis happens on your phone. No images ever leave your device.</p>
          </div>
          <div className="flex gap-3 p-4 bg-blue-50 rounded-2xl border border-blue-100">
            <Lock className="w-5 h-5 text-blue-600 flex-shrink-0" />
            <p className="text-sm text-blue-800">Zero-Bypass: Multi-layered security prevents uninstallation during moments of weakness.</p>
          </div>
        </div>
      )
    },
    {
      title: "Step 1: Screen Capture",
      description: "To detect inappropriate content in real-time, Guardian needs permission to monitor your display.",
      icon: <EyeOff className="w-12 h-12 text-blue-500" />,
      content: (
        <div className="space-y-6">
          <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200 text-left">
            <h4 className="font-semibold text-slate-900 mb-2">How it works:</h4>
            <ul className="space-y-2 text-sm text-slate-600">
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                Captures screen frames 30 times per second
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                AI scans for explicit content instantly
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                Frames are deleted immediately after scan
              </li>
            </ul>
          </div>
          <button className="w-full py-4 bg-slate-900 text-white rounded-2xl font-medium hover:bg-slate-800 transition-all">
            Grant Screen Capture Permission
          </button>
        </div>
      )
    },
    {
      title: "Step 2: Accessibility Service",
      description: "This is the 'Lockdown Agent'. It allows Guardian to draw blurs over content and prevent uninstallation.",
      icon: <ShieldAlert className="w-12 h-12 text-amber-500" />,
      content: (
        <div className="space-y-6">
          <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100 flex gap-3 text-left">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0" />
            <p className="text-xs text-amber-800">Crucial: This service must be enabled for the 'Blur' functionality and 'Anti-Uninstall' protection to work.</p>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-2xl">
              <span className="text-sm font-medium text-slate-700">Draw Over Other Apps</span>
              <div className="w-10 h-5 bg-emerald-500 rounded-full relative">
                <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full" />
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-2xl">
              <span className="text-sm font-medium text-slate-700">Monitor UI Interactions</span>
              <div className="w-10 h-5 bg-emerald-500 rounded-full relative">
                <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full" />
              </div>
            </div>
          </div>
          <button className="w-full py-4 bg-slate-900 text-white rounded-2xl font-medium hover:bg-slate-800 transition-all">
            Enable Accessibility Service
          </button>
        </div>
      )
    },
    {
      title: "Step 3: Device Administrator",
      description: "The final barrier. This makes Guardian a system-level protector that cannot be easily removed.",
      icon: <Lock className="w-12 h-12 text-red-500" />,
      content: (
        <div className="space-y-6">
          <div className="text-center p-8 bg-slate-900 rounded-3xl text-white relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-emerald-500/10 animate-pulse" />
            <Smartphone className="w-16 h-16 mx-auto mb-4 text-emerald-400" />
            <h4 className="text-lg font-bold mb-2">Impenetrable Persistence</h4>
            <p className="text-slate-400 text-sm">Once activated, standard uninstallation is disabled. You are now fully protected.</p>
          </div>
          <button className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-medium hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20">
            Activate Device Admin
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-emerald-200 selection:text-emerald-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div 
              className="flex items-center gap-2 cursor-pointer" 
              onClick={() => setCurrentView('landing')}
            >
              <div className="bg-emerald-500 p-2 rounded-xl text-white">
                <Shield className="w-6 h-6" />
              </div>
              <span className="font-bold text-xl tracking-tight text-slate-900">Project Guardian</span>
            </div>
            
            {/* Desktop Nav */}
            <div className="hidden md:flex items-center space-x-8">
              {currentView === 'landing' ? (
                <>
                  <a href="#mission" className="text-sm font-medium text-slate-600 hover:text-emerald-600 transition-colors">Mission</a>
                  <a href="#architecture" className="text-sm font-medium text-slate-600 hover:text-emerald-600 transition-colors">Architecture</a>
                  <a href="#security" className="text-sm font-medium text-slate-600 hover:text-emerald-600 transition-colors">Security</a>
                  <a href="#pricing" className="text-sm font-medium text-slate-600 hover:text-emerald-600 transition-colors">Pricing</a>
                </>
              ) : null}
              <button 
                onClick={() => setCurrentView('settings')}
                className="flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-emerald-600 transition-colors"
              >
                <Settings className="w-4 h-4" />
                Dashboard
              </button>
              <button 
                onClick={() => setCurrentView('onboarding')}
                className="bg-slate-900 text-white px-5 py-2.5 rounded-full text-sm font-medium hover:bg-slate-800 transition-colors"
              >
                Get Started
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center">
              <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-slate-600 hover:text-slate-900">
                {isMobileMenuOpen ? <XIcon className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-4 space-y-1 shadow-lg">
            {currentView === 'landing' && (
              <>
                <a href="#mission" onClick={() => setIsMobileMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">Mission</a>
                <a href="#architecture" onClick={() => setIsMobileMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">Architecture</a>
                <a href="#security" onClick={() => setIsMobileMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">Security</a>
                <a href="#pricing" onClick={() => setIsMobileMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">Pricing</a>
              </>
            )}
            <button 
              onClick={() => {
                setCurrentView('settings');
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50"
            >
              <Settings className="w-5 h-5" />
              Dashboard Settings
            </button>
          </div>
        )}
      </nav>

      <main>
        {currentView === 'onboarding' ? (
          <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4 bg-slate-50">
            <div className="max-w-xl w-full bg-white rounded-[40px] shadow-2xl shadow-slate-200/50 border border-slate-100 overflow-hidden relative">
              {/* Progress Bar */}
              <div className="absolute top-0 left-0 w-full h-1.5 bg-slate-100">
                <motion.div 
                  className="h-full bg-emerald-500"
                  initial={{ width: 0 }}
                  animate={{ width: `${((onboardingStep + 1) / onboardingSteps.length) * 100}%` }}
                />
              </div>

              <div className="p-8 sm:p-12">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={onboardingStep}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="text-center"
                  >
                    <div className="inline-flex p-4 bg-slate-50 rounded-3xl mb-6">
                      {onboardingSteps[onboardingStep].icon}
                    </div>
                    <h2 className="text-3xl font-bold text-slate-900 mb-4">
                      {onboardingSteps[onboardingStep].title}
                    </h2>
                    <p className="text-slate-600 mb-8 leading-relaxed">
                      {onboardingSteps[onboardingStep].description}
                    </p>
                    
                    {onboardingSteps[onboardingStep].content}
                  </motion.div>
                </AnimatePresence>

                <div className="mt-12 flex items-center justify-between">
                  <button
                    onClick={() => onboardingStep > 0 && setOnboardingStep(onboardingStep - 1)}
                    disabled={onboardingStep === 0}
                    className={`flex items-center gap-2 text-sm font-medium transition-colors ${
                      onboardingStep === 0 ? 'text-slate-300' : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    <ChevronLeft className="w-4 h-4" />
                    Back
                  </button>
                  
                  {onboardingStep < onboardingSteps.length - 1 ? (
                    <button
                      onClick={() => setOnboardingStep(onboardingStep + 1)}
                      className="flex items-center gap-2 bg-slate-900 text-white px-8 py-3 rounded-2xl font-medium hover:bg-slate-800 transition-all"
                    >
                      Continue
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={completeOnboarding}
                      className="flex items-center gap-2 bg-emerald-600 text-white px-8 py-3 rounded-2xl font-medium hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20"
                    >
                      Finish Setup
                      <ShieldCheck className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : currentView === 'landing' ? (
          <>
            {/* Hero Section */}
        <section className="relative pt-24 pb-32 overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-emerald-100/50 via-slate-50 to-slate-50 -z-10"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-sm font-medium mb-8">
                <ShieldCheck className="w-4 h-4" />
                Sompurno System Blueprint
              </span>
              <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-slate-900 mb-8 max-w-4xl mx-auto leading-tight">
                Advanced On-Device <br className="hidden md:block" />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-500">
                  Content Filtering
                </span>
              </h1>
              <p className="text-xl text-slate-600 mb-10 max-w-2xl mx-auto leading-relaxed">
                An AI-powered modesty enforcement application designed to protect your digital gaze. Real-time screen analysis, zero-bypass tolerance, and 100% privacy-first on-device processing.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  onClick={() => setCurrentView('onboarding')}
                  className="bg-emerald-600 text-white px-8 py-4 rounded-full text-lg font-medium hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-600/20"
                >
                  Get Started Now
                </button>
                <button className="bg-white text-slate-700 border border-slate-200 px-8 py-4 rounded-full text-lg font-medium hover:bg-slate-50 transition-colors shadow-sm">
                  Read the Whitepaper
                </button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Mission & Core Values */}
        <section id="mission" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Mission & Core Values</h2>
              <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                Built on the principle of lowering the gaze, Project Guardian operates directly at the display rendering layer for universal protection.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  icon: <EyeOff className="w-6 h-6 text-emerald-600" />,
                  title: "Total Visual Protection",
                  description: "Instantly blurs explicit or immodest content across any app (Facebook, Instagram, Browser) before cognitive processing occurs."
                },
                {
                  icon: <Lock className="w-6 h-6 text-emerald-600" />,
                  title: "Impenetrable Persistence",
                  description: "Zero-bypass tolerance. Advanced system-level locks prevent uninstallation or force-stopping during moments of weakness."
                },
                {
                  icon: <ShieldCheck className="w-6 h-6 text-emerald-600" />,
                  title: "Privacy-First (On-Device AI)",
                  description: "100% on-device inference using TensorFlow Lite. No images or visual data are ever transmitted to remote servers."
                },
                {
                  icon: <Cpu className="w-6 h-6 text-emerald-600" />,
                  title: "Granular Filtering",
                  description: "Context-aware selectivity. Draws localized bounding boxes to blur only inappropriate pixels, leaving safe content interactive."
                }
              ].map((value, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-slate-50 rounded-3xl p-8 border border-slate-100 hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300"
                >
                  <div className="bg-white w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm mb-6">
                    {value.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-3">{value.title}</h3>
                  <p className="text-slate-600 leading-relaxed">{value.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Agentic Architecture */}
        <section id="architecture" className="py-24 bg-slate-900 text-white overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-10 pointer-events-none">
            <div className="absolute -top-[20%] -right-[10%] w-[70%] h-[70%] rounded-full bg-emerald-500 blur-[120px]"></div>
            <div className="absolute -bottom-[20%] -left-[10%] w-[60%] h-[60%] rounded-full bg-blue-500 blur-[120px]"></div>
          </div>
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Agentic Architecture</h2>
              <p className="text-lg text-slate-400 max-w-2xl mx-auto">
                A robust, multi-layered system utilizing a 'Main Agent' and 'Sub-Agent' pattern for fast, crash-free performance.
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              {/* Main Agents */}
              <div className="space-y-6">
                <h3 className="text-2xl font-semibold text-emerald-400 mb-6 flex items-center gap-2">
                  <Shield className="w-6 h-6" /> Supervisors (Main Agents)
                </h3>
                
                <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-6">
                  <h4 className="text-lg font-medium text-white mb-2">Supreme Commander</h4>
                  <p className="text-slate-400 text-sm">Monitors overall system health. Instantly revives any agent if an attempt is made to kill it.</p>
                </div>
                
                <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-6">
                  <h4 className="text-lg font-medium text-white mb-2">Operation Director</h4>
                  <p className="text-slate-400 text-sm">Acts as the task manager. Receives signals from the AI and commands the UI lockdown agent to execute screen blurs.</p>
                </div>
              </div>

              {/* Sub Agents */}
              <div className="space-y-6">
                <h3 className="text-2xl font-semibold text-blue-400 mb-6 flex items-center gap-2">
                  <Cpu className="w-6 h-6" /> Workers (Sub-Agents)
                </h3>
                
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-5">
                    <EyeOff className="w-5 h-5 text-blue-400 mb-3" />
                    <h4 className="text-base font-medium text-white mb-2">Deep Vision Agent (AI)</h4>
                    <p className="text-slate-400 text-xs">Uses MediaProjection API & YOLOv11/MobileNet to continuously capture frames and detect inappropriate content.</p>
                  </div>
                  
                  <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-5">
                    <Network className="w-5 h-5 text-blue-400 mb-3" />
                    <h4 className="text-base font-medium text-white mb-2">Network Shield Agent</h4>
                    <p className="text-slate-400 text-xs">Creates a local VPN to block malicious and explicit domains in the background.</p>
                  </div>
                  
                  <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-5">
                    <ShieldAlert className="w-5 h-5 text-blue-400 mb-3" />
                    <h4 className="text-base font-medium text-white mb-2">UI Lockdown Agent</h4>
                    <p className="text-slate-400 text-xs">Utilizes AccessibilityService to instantly drop a black/blur overlay on detected content.</p>
                  </div>
                  
                  <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-5">
                    <Lock className="w-5 h-5 text-blue-400 mb-3" />
                    <h4 className="text-base font-medium text-white mb-2">Unyielding Sentinel</h4>
                    <p className="text-slate-400 text-xs">Monitors the Settings app. Redirects to Home screen if uninstallation is attempted.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Security Barriers */}
        <section id="security" className="py-24 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Security Barriers (Anti-Bypass System)</h2>
              <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                Designed to be the ultimate digital barrier, protecting users during moments of weakness with multi-layered defenses.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {[
                {
                  title: "Device Administrator",
                  desc: "App is granted admin privileges, making standard uninstallation impossible without deep system access.",
                  icon: <ShieldCheck className="w-5 h-5" />
                },
                {
                  title: "Accessibility Lock",
                  desc: "System blocks clicks on the uninstall button before they can even register.",
                  icon: <Lock className="w-5 h-5" />
                },
                {
                  title: "Accountability Partner",
                  desc: "Attempts to disable VPN or uninstall trigger instant SMS/Email alerts to a trusted friend or partner.",
                  icon: <Network className="w-5 h-5" />
                },
                {
                  title: "Uninstall Delay",
                  desc: "Mandatory 24 to 48-hour cool-down period required before uninstallation can proceed.",
                  icon: <Clock className="w-5 h-5" />
                }
              ].map((barrier, idx) => (
                <div key={idx} className="flex gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                    {barrier.icon}
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-slate-900 mb-1">{barrier.title}</h4>
                    <p className="text-slate-600 text-sm leading-relaxed">{barrier.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section id="pricing" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Subscription & Pricing Model</h2>
              <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                Supporting continuous AI model updates and development.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full max-w-5xl mx-auto text-left border-collapse">
                <thead>
                  <tr>
                    <th className="p-4 border-b-2 border-slate-200 bg-slate-50 text-slate-900 font-semibold rounded-tl-2xl">Feature / Plan</th>
                    <th className="p-4 border-b-2 border-slate-200 bg-slate-50 text-slate-900 font-semibold">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                        Basic (Free)
                      </div>
                    </th>
                    <th className="p-4 border-b-2 border-slate-200 bg-slate-50 text-slate-900 font-semibold">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                        Premium (Pro)
                      </div>
                    </th>
                    <th className="p-4 border-b-2 border-slate-200 bg-slate-50 text-slate-900 font-semibold rounded-tr-2xl">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                        Family/Group
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  <tr className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-medium text-slate-900">Monthly Price</td>
                    <td className="p-4 text-slate-600">0 TK / Free</td>
                    <td className="p-4 text-slate-600">~ 500 TK ($4.99)</td>
                    <td className="p-4 text-slate-600">~ 1200 TK ($11.99)</td>
                  </tr>
                  <tr className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-medium text-slate-900">DNS Website Blocking</td>
                    <td className="p-4"><Check className="w-5 h-5 text-emerald-500" /></td>
                    <td className="p-4"><Check className="w-5 h-5 text-emerald-500" /></td>
                    <td className="p-4"><Check className="w-5 h-5 text-emerald-500" /></td>
                  </tr>
                  <tr className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-medium text-slate-900">Basic Safe Search</td>
                    <td className="p-4"><Check className="w-5 h-5 text-emerald-500" /></td>
                    <td className="p-4"><Check className="w-5 h-5 text-emerald-500" /></td>
                    <td className="p-4"><Check className="w-5 h-5 text-emerald-500" /></td>
                  </tr>
                  <tr className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-medium text-slate-900">Real-time AI Image Blurring</td>
                    <td className="p-4"><X className="w-5 h-5 text-red-400" /></td>
                    <td className="p-4 text-slate-600 flex items-center gap-2"><Check className="w-5 h-5 text-emerald-500" /> All Apps</td>
                    <td className="p-4 text-slate-600 flex items-center gap-2"><Check className="w-5 h-5 text-emerald-500" /> All Apps</td>
                  </tr>
                  <tr className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-medium text-slate-900">Soft-Porn/Attire Filter</td>
                    <td className="p-4"><X className="w-5 h-5 text-red-400" /></td>
                    <td className="p-4 text-slate-600 flex items-center gap-2"><Check className="w-5 h-5 text-emerald-500" /> Strict Mode</td>
                    <td className="p-4 text-slate-600 flex items-center gap-2"><Check className="w-5 h-5 text-emerald-500" /> Strict Mode</td>
                  </tr>
                  <tr className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-medium text-slate-900">Anti-Uninstall Protection</td>
                    <td className="p-4"><X className="w-5 h-5 text-red-400" /></td>
                    <td className="p-4 text-slate-600 flex items-center gap-2"><Check className="w-5 h-5 text-emerald-500" /> Max Security</td>
                    <td className="p-4 text-slate-600 flex items-center gap-2"><Check className="w-5 h-5 text-emerald-500" /> Max Security</td>
                  </tr>
                  <tr className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-medium text-slate-900">Accountability Partner Alert</td>
                    <td className="p-4"><X className="w-5 h-5 text-red-400" /></td>
                    <td className="p-4 text-slate-600 flex items-center gap-2"><Check className="w-5 h-5 text-emerald-500" /> 1 Partner</td>
                    <td className="p-4 text-slate-600 flex items-center gap-2"><Check className="w-5 h-5 text-emerald-500" /> Up to 3</td>
                  </tr>
                  <tr className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-medium text-slate-900">Number of Devices</td>
                    <td className="p-4 text-slate-600">1 Device</td>
                    <td className="p-4 text-slate-600">1 Device</td>
                    <td className="p-4 text-slate-600">Up to 5 Devices</td>
                  </tr>
                  <tr className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-medium text-slate-900 rounded-bl-2xl">Parent/Admin Dashboard</td>
                    <td className="p-4"><X className="w-5 h-5 text-red-400" /></td>
                    <td className="p-4"><X className="w-5 h-5 text-red-400" /></td>
                    <td className="p-4 rounded-br-2xl"><Check className="w-5 h-5 text-emerald-500" /></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </section>
          </>
        ) : (
          <SettingsPanel />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-16 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <Shield className="w-8 h-8 text-emerald-500" />
                <span className="font-bold text-2xl text-white tracking-tight">Project Guardian</span>
              </div>
              <p className="text-slate-400 max-w-sm leading-relaxed">
                Protecting your digital gaze with advanced on-device AI. 
                Universal content filtering designed for privacy, persistence, and peace of mind.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-6 uppercase text-xs tracking-widest">Product</h4>
              <ul className="space-y-4 text-sm">
                <li><a href="#mission" className="hover:text-emerald-400 transition-colors">Mission</a></li>
                <li><a href="#architecture" className="hover:text-emerald-400 transition-colors">Architecture</a></li>
                <li><a href="#security" className="hover:text-emerald-400 transition-colors">Security</a></li>
                <li><a href="#pricing" className="hover:text-emerald-400 transition-colors">Pricing</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-6 uppercase text-xs tracking-widest">Legal</h4>
              <ul className="space-y-4 text-sm">
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Cookie Policy</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Contact</a></li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-xs tracking-wide">
              © 2026 Project Guardian. All rights reserved. Built for the Sompurno System.
            </p>
            <div className="flex gap-6 text-xs uppercase tracking-widest font-medium">
              <span className="text-slate-500">v1.0.4-beta</span>
              <span className="text-emerald-500/50">System Active</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
