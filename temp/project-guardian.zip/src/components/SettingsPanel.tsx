import { useState, useEffect } from 'react';
import React from 'react';
import { Shield, EyeOff, Bell, Users, Lock, Save, AlertTriangle, CheckCircle2, Loader2, Sparkles, Brain, Image as ImageIcon, Send, Globe, Trash2, Plus, Smartphone, Clock, Upload, Download, Activity } from 'lucide-react';
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

export default function SettingsPanel() {
  const [activeTab, setActiveTab] = useState('filtering');
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState({
    immodestAttire: 'Strict (Recommended)',
    unveiledFaces: 'Strict',
    obfuscationStyle: 'Heavy Gaussian Blur',
    realTimeAlerts: true,
    weeklySummary: true,
    partnerName: 'Ahmed Ali',
    partnerEmail: 'ahmed@example.com',
    partnerPhone: '',
    alertUninstall: true,
    alertDisabled: true,
    alertHighFrequency: false,
    uninstallCooldown: '24 Hours',
    enforceSafeSearch: true,
    enforceYouTubeRestricted: true,
    lockdownMode: false,
    settingsPin: '',
    requirePinForChanges: false,
    safeModeEndTime: null as number | null
  });

  const [isSafeModePinPrompt, setIsSafeModePinPrompt] = useState(false);
  const [safeModePinInput, setSafeModePinInput] = useState('');
  const [safeModePinError, setSafeModePinError] = useState('');

  const isSafeModeActive = settings.safeModeEndTime !== null && settings.safeModeEndTime > Date.now();

  useEffect(() => {
    if (isSafeModeActive) {
      const timer = setInterval(() => {
        if (Date.now() > (settings.safeModeEndTime || 0)) {
          updateSetting('safeModeEndTime', null);
        }
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isSafeModeActive, settings.safeModeEndTime]);

  const toggleSafeMode = () => {
    if (isSafeModeActive) {
      updateSetting('safeModeEndTime', null);
    } else {
      setIsSafeModePinPrompt(true);
    }
  };

  const handleSafeModeUnlock = () => {
    if (safeModePinInput === settings.settingsPin) {
      updateSetting('safeModeEndTime', Date.now() + 3600000);
      setIsSafeModePinPrompt(false);
      setSafeModePinInput('');
      setSafeModePinError('');
    } else {
      setSafeModePinError('Incorrect PIN');
    }
  };

  const [isLocked, setIsLocked] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  // Gemini State
  const [safetyQuery, setSafetyQuery] = useState('');
  const [safetyResponse, setSafetyResponse] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [deepAnalysis, setDeepAnalysis] = useState('');
  const [isDeepAnalyzing, setIsDeepAnalyzing] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [hasKey, setHasKey] = useState(false);
  const [isSendingAlert, setIsSendingAlert] = useState(false);
  const [alertStatus, setAlertStatus] = useState<string | null>(null);

  // App Blocking State
  const [blockedApps, setBlockedApps] = useState([
    { id: '1', name: 'Instagram', category: 'Social Media', isBlocked: true, timeLimit: 'None', timeUsed: 0, lastResetDate: new Date().toDateString() },
    { id: '2', name: 'TikTok', category: 'Social Media', isBlocked: true, timeLimit: 'None', timeUsed: 0, lastResetDate: new Date().toDateString() },
    { id: '3', name: 'Chrome', category: 'Browser', isBlocked: false, timeLimit: '1 Hour', timeUsed: 0, lastResetDate: new Date().toDateString() },
    { id: '4', name: 'Snapchat', category: 'Social Media', isBlocked: true, timeLimit: 'None', timeUsed: 0, lastResetDate: new Date().toDateString() },
    { id: '5', name: 'YouTube', category: 'Entertainment', isBlocked: false, timeLimit: '2 Hours', timeUsed: 0, lastResetDate: new Date().toDateString() },
    { id: '6', name: 'Discord', category: 'Communication', isBlocked: false, timeLimit: 'None', timeUsed: 0, lastResetDate: new Date().toDateString() },
  ]);

  const toggleAppBlock = (id: string) => {
    setBlockedApps(apps => apps.map(app => 
      app.id === id ? { ...app, isBlocked: !app.isBlocked } : app
    ));
  };

  const updateAppTimeLimit = (id: string, limit: string) => {
    setBlockedApps(apps => apps.map(app => 
      app.id === id ? { ...app, timeLimit: limit } : app
    ));
  };

  // Simulate time usage for demo
  useEffect(() => {
    const interval = setInterval(() => {
      const today = new Date().toDateString();
      setBlockedApps(apps => apps.map(app => {
        // Reset if new day
        if (app.lastResetDate !== today) {
          return { ...app, timeUsed: 0, lastResetDate: today };
        }
        
        // Simulate usage if not blocked and not already exceeded
        if (!app.isBlocked && app.timeLimit !== 'None') {
          const limitMs = app.timeLimit === '15 Mins' ? 15 * 60 * 1000 :
                          app.timeLimit === '30 Mins' ? 30 * 60 * 1000 :
                          app.timeLimit === '1 Hour' ? 60 * 60 * 1000 :
                          app.timeLimit === '2 Hours' ? 120 * 60 * 1000 : 0;
          
          if (app.timeUsed < limitMs) {
            return { ...app, timeUsed: app.timeUsed + 60000 }; // Add 1 minute
          } else {
            return { ...app, isBlocked: true }; // Block if limit reached
          }
        }
        return app;
      }));
    }, 5000); // Update every 5 seconds for demo
    return () => clearInterval(interval);
  }, []);

  // DNS State
  const [blockedDomains, setBlockedDomains] = useState<{domain: string, category: string, added_at: string}[]>([]);
  const [newDomain, setNewDomain] = useState('');
  const [newCategory, setNewCategory] = useState('Adult');
  const [isAddingDomain, setIsAddingDomain] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [testUrl, setTestUrl] = useState('');
  const [testResult, setTestResult] = useState<{isBlocked: boolean, category?: string, message: string} | null>(null);
  const [sortConfig, setSortConfig] = useState<{ key: 'domain' | 'category' | 'added_at', direction: 'asc' | 'desc' }>({ key: 'added_at', direction: 'desc' });

  // AI Model State
  const [modelStatus, setModelStatus] = useState({
    version: 'v2.4.1 (MobileNet-V3)',
    lastUpdated: new Date().toISOString(),
    isUpdating: false,
    updateMessage: '',
    progress: 0
  });
  const [liveScannerActive, setLiveScannerActive] = useState(false);
  const [liveLogs, setLiveLogs] = useState<{id: number, url: string, status: 'safe' | 'blocked', reason?: string, time: string}[]>([]);

  const parseDate = (dateStr: string) => {
    if (!dateStr) return 'Unknown';
    const isoStr = dateStr.includes('T') ? dateStr : dateStr.replace(' ', 'T') + 'Z';
    const d = new Date(isoStr);
    return isNaN(d.getTime()) ? 'Unknown' : d.toLocaleDateString();
  };

  const sortedDomains = [...blockedDomains].sort((a, b) => {
    const aVal = a[sortConfig.key] || '';
    const bVal = b[sortConfig.key] || '';
    if (aVal < bVal) {
      return sortConfig.direction === 'asc' ? -1 : 1;
    }
    if (aVal > bVal) {
      return sortConfig.direction === 'asc' ? 1 : -1;
    }
    return 0;
  });

  const handleSort = (key: 'domain' | 'category' | 'added_at') => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  useEffect(() => {
    const domain = newDomain.toLowerCase();
    if (domain.match(/xxx|porn|sex|nude|onlyfans|cam/)) {
      setNewCategory('Adult');
    } else if (domain.match(/bet|casino|gamble|poker|slots/)) {
      setNewCategory('Gambling');
    } else if (domain.match(/facebook|twitter|instagram|tiktok|snapchat|reddit/)) {
      setNewCategory('Social Media');
    } else if (domain.match(/virus|hack|malware|phish/)) {
      setNewCategory('Malware');
    }
  }, [newDomain]);

  useEffect(() => {
    const checkKey = async () => {
      const win = window as any;
      if (win.aistudio) {
        const selected = await win.aistudio.hasSelectedApiKey();
        setHasKey(selected);
      }
    };
    checkKey();
  }, []);

  const handleOpenKeyDialog = async () => {
    const win = window as any;
    if (win.aistudio) {
      await win.aistudio.openSelectKey();
      setHasKey(true);
    }
  };

  const handleSafetyConsultant = async () => {
    if (!safetyQuery.trim()) return;
    setIsAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite-preview",
        contents: safetyQuery,
        config: {
          systemInstruction: "You are a safety consultant for Project Guardian. Provide fast, concise advice on web safety and content filtering."
        }
      });
      setSafetyResponse(response.text || 'No response received.');
    } catch (err) {
      console.error('Safety Consultant Error:', err);
      setSafetyResponse('Error analyzing query. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleDeepAnalysis = async () => {
    if (!safetyQuery.trim()) return;
    setIsDeepAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: `Perform a deep safety audit on this topic: ${safetyQuery}`,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
          systemInstruction: "You are a senior security auditor. Provide a comprehensive, high-reasoning analysis of potential digital threats and safety measures."
        }
      });
      setDeepAnalysis(response.text || 'No deep analysis available.');
    } catch (err) {
      console.error('Deep Analysis Error:', err);
      setDeepAnalysis('Error performing deep analysis.');
    } finally {
      setIsDeepAnalyzing(false);
    }
  };

  const handleGenerateSafetyVisual = async () => {
    if (!hasKey) {
      await handleOpenKeyDialog();
      return;
    }
    setIsGeneratingImage(true);
    try {
      // Get the latest API key from the platform
      const apiKey = await (window as any).aistudio.getApiKey();
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: {
          parts: [{ text: `A professional, high-tech digital safety and protection themed graphic, ${safetyQuery || 'shielding a device from harmful waves'}` }]
        },
        config: {
          imageConfig: {
            aspectRatio: "1:1",
            imageSize: imageSize
          }
        }
      });
      
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          setGeneratedImage(`data:image/png;base64,${part.inlineData.data}`);
          break;
        }
      }
    } catch (err: any) {
      console.error('Image Generation Error:', err);
      if (err.message?.includes("PERMISSION_DENIED") || err.message?.includes("Requested entity was not found")) {
        setHasKey(false);
        alert("API Key error or permission denied. Please re-select your key.");
      } else {
        alert("Failed to generate image. Please try again.");
      }
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleSendAlert = async (type: string) => {
    if (!settings.partnerEmail && !settings.partnerPhone) {
      alert("Please provide a partner email or phone number first.");
      return;
    }

    setIsSendingAlert(true);
    setAlertStatus(null);
    try {
      const response = await fetch('/api/alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type,
          partnerName: settings.partnerName,
          partnerEmail: settings.partnerEmail,
          partnerPhone: settings.partnerPhone
        })
      });
      const data = await response.json();
      if (data.success) {
        setAlertStatus(data.message);
        setTimeout(() => setAlertStatus(null), 5000);
      }
    } catch (err) {
      console.error('Alert Error:', err);
      alert("Failed to send alert.");
    } finally {
      setIsSendingAlert(false);
    }
  };

  const fetchBlockedDomains = async () => {
    try {
      const res = await fetch('/api/blocked-domains');
      const data = await res.json();
      setBlockedDomains(data);
    } catch (err) {
      console.error('Failed to fetch domains:', err);
    }
  };

  const handleAddDomain = async () => {
    if (!newDomain.trim()) return;
    setIsAddingDomain(true);
    try {
      const res = await fetch('/api/blocked-domains', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: newDomain.trim().toLowerCase(), category: newCategory })
      });
      if (res.ok) {
        setNewDomain('');
        setNewCategory('Adult');
        fetchBlockedDomains();
      } else {
        const data = await res.json();
        alert(data.error || "Failed to add domain");
      }
    } catch (err) {
      console.error('Add Domain Error:', err);
    } finally {
      setIsAddingDomain(false);
    }
  };

  const handleDeleteDomain = async (domain: string) => {
    try {
      await fetch(`/api/blocked-domains/${domain}`, { method: 'DELETE' });
      fetchBlockedDomains();
    } catch (err) {
      console.error('Delete Domain Error:', err);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    try {
      const text = await file.text();
      const domains = text.split('\n').map(d => d.trim()).filter(d => d && !d.startsWith('#'));

      let addedCount = 0;
      for (const domain of domains) {
        let category = 'Custom';
        if (domain.match(/xxx|porn|sex|nude|onlyfans|cam/i)) category = 'Adult';
        else if (domain.match(/bet|casino|gamble|poker|slots/i)) category = 'Gambling';
        else if (domain.match(/facebook|twitter|instagram|tiktok|snapchat|reddit/i)) category = 'Social Media';
        else if (domain.match(/virus|hack|malware|phish/i)) category = 'Malware';

        const res = await fetch('/api/blocked-domains', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ domain: domain.toLowerCase(), category })
        });
        if (res.ok) addedCount++;
      }
      alert(`Successfully imported ${addedCount} domains.`);
      fetchBlockedDomains();
    } catch (err) {
      console.error('Import error:', err);
      alert('Failed to import domains.');
    } finally {
      setIsImporting(false);
      event.target.value = '';
    }
  };

  const handleExportDomains = () => {
    if (blockedDomains.length === 0) {
      alert("No domains to export.");
      return;
    }
    const content = blockedDomains.map(d => d.domain).join('\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'blocked-domains.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSyncRemote = async () => {
    setIsSyncing(true);
    try {
      // Simulate fetching from a remote source
      await new Promise(resolve => setTimeout(resolve, 2000));
      const mockRemoteDomains = [
        { domain: 'malicious-tracker.com', category: 'Malware' },
        { domain: 'phishing-login-fake.net', category: 'Malware' },
        { domain: 'ad-server-spam.org', category: 'Custom' }
      ];
      
      let addedCount = 0;
      for (const item of mockRemoteDomains) {
        const res = await fetch('/api/blocked-domains', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(item)
        });
        if (res.ok) addedCount++;
      }
      alert(`Synced ${addedCount} new domains from remote source.`);
      fetchBlockedDomains();
    } catch (err) {
      console.error('Sync error:', err);
      alert('Failed to sync from remote source.');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleTestUrl = () => {
    if (!testUrl.trim()) return;
    try {
      const urlObj = new URL(testUrl.startsWith('http') ? testUrl : `https://${testUrl}`);
      const hostname = urlObj.hostname.replace(/^www\./, '').toLowerCase();
      
      const match = blockedDomains.find(d => 
        hostname === d.domain || hostname.endsWith(`.${d.domain}`)
      );

      if (match) {
        setTestResult({
          isBlocked: true,
          category: match.category,
          message: `Blocked by rule: ${match.domain}`
        });
      } else {
        setTestResult({
          isBlocked: false,
          message: 'URL is safe and not in blocklist.'
        });
      }
    } catch (e) {
      setTestResult({
        isBlocked: false,
        message: 'Invalid URL format.'
      });
    }
  };

  const handleUpdateModel = async () => {
    setModelStatus(prev => ({ ...prev, isUpdating: true, updateMessage: 'Downloading model weights...', progress: 10 }));
    
    // Simulate model download and compilation
    await new Promise(resolve => setTimeout(resolve, 1000));
    setModelStatus(prev => ({ ...prev, updateMessage: 'Downloading model weights...', progress: 50 }));
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    setModelStatus(prev => ({ ...prev, updateMessage: 'Compiling for Neural Engine...', progress: 80 }));
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    setModelStatus({
      version: 'v2.5.0 (MobileNet-V4-Optimized)',
      lastUpdated: new Date().toISOString(),
      isUpdating: false,
      updateMessage: 'Model updated successfully.',
      progress: 100
    });
    
    setTimeout(() => {
      setModelStatus(prev => ({ ...prev, updateMessage: '', progress: 0 }));
    }, 3000);
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (liveScannerActive) {
      interval = setInterval(() => {
        const mockUrls = [
          'https://facebook.com/feed',
          'https://google.com/search?q=news',
          'https://example-malware-site.com/download',
          'https://youtube.com/watch?v=123',
          'https://suspicious-tracker.net/pixel'
        ];
        const randomUrl = mockUrls[Math.floor(Math.random() * mockUrls.length)];
        const isSuspicious = randomUrl.includes('malware') || randomUrl.includes('tracker');
        
        setLiveLogs(prev => {
          const newLogs = [{
            id: Date.now(),
            url: randomUrl,
            status: isSuspicious ? 'blocked' : 'safe' as const,
            reason: isSuspicious ? 'AI Pattern Match (Confidence: 98%)' : undefined,
            time: new Date().toLocaleTimeString()
          }, ...prev];
          return newLogs.slice(0, 10); // Keep last 10
        });
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [liveScannerActive]);

  useEffect(() => {
    fetchBlockedDomains();
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (Object.keys(data).length > 0) {
          setSettings(prev => ({ ...prev, ...data }));
          if (data.requirePinForChanges && data.settingsPin) {
            setIsLocked(true);
          }
        }
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to fetch settings:', err);
        setLoading(false);
      });
  }, []);

  const handleSave = async () => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      if (res.ok) {
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
      }
    } catch (err) {
      console.error('Failed to save settings:', err);
    }
  };

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleUnlock = () => {
    if (pinInput === settings.settingsPin) {
      setIsLocked(false);
      setPinError('');
      setPinInput('');
    } else {
      setPinError('Incorrect PIN');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Guardian Settings</h1>
          <p className="text-slate-600 mt-2">Customize your protection levels and accountability preferences.</p>
        </div>
        <button
          onClick={() => updateSetting('lockdownMode', !settings.lockdownMode)}
          className={`px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-colors ${
            settings.lockdownMode 
              ? 'bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-200' 
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          <Shield className="w-5 h-5" />
          {settings.lockdownMode ? 'Lockdown Active' : 'Enable Lockdown'}
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0">
          <nav className="space-y-1">
            <button
              onClick={() => setActiveTab('filtering')}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors ${
                activeTab === 'filtering' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <EyeOff className="w-5 h-5" />
              Filtering Levels
            </button>
            <button
              onClick={() => setActiveTab('notifications')}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors ${
                activeTab === 'notifications' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Bell className="w-5 h-5" />
              Notifications
            </button>
            <button
              onClick={() => setActiveTab('accountability')}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors ${
                activeTab === 'accountability' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Users className="w-5 h-5" />
              Accountability Partner
            </button>
            <button
              onClick={() => setActiveTab('security')}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors ${
                activeTab === 'security' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Lock className="w-5 h-5" />
              Security & Anti-Bypass
            </button>
            <button
              onClick={() => setActiveTab('dns')}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors ${
                activeTab === 'dns' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Globe className="w-5 h-5" />
              DNS Blocking
            </button>
            <button
              onClick={() => setActiveTab('apps')}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors ${
                activeTab === 'apps' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Smartphone className="w-5 h-5" />
              App Blocking
            </button>
            <button
              onClick={() => setActiveTab('intelligence')}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors ${
                activeTab === 'intelligence' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Sparkles className="w-5 h-5" />
              Safety Intelligence
            </button>
            <button
              onClick={() => setActiveTab('ai-models')}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors ${
                activeTab === 'ai-models' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Brain className="w-5 h-5" />
              AI Models & Scanner
            </button>
          </nav>
        </div>

        {/* Content Area */}
        <div className="flex-1 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden relative">
          {isLocked ? (
            <div className="absolute inset-0 z-10 bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center p-8">
              <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200 shadow-xl max-w-sm w-full text-center">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Lock className="w-8 h-8" />
                </div>
                <h2 className="text-xl font-bold text-slate-900 mb-2">Settings Locked</h2>
                <p className="text-sm text-slate-500 mb-6">Enter your PIN to access and modify Guardian settings.</p>
                
                <div className="space-y-4">
                  <input 
                    type="password" 
                    maxLength={6}
                    placeholder="Enter PIN"
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleUnlock()}
                    className="bg-white border border-slate-200 text-slate-900 text-center text-lg tracking-widest rounded-xl focus:ring-emerald-500 focus:border-emerald-500 block w-full p-4"
                  />
                  {pinError && <p className="text-red-500 text-sm">{pinError}</p>}
                  <button
                    onClick={handleUnlock}
                    className="w-full bg-emerald-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-emerald-700 transition-colors"
                  >
                    Unlock Settings
                  </button>
                </div>
              </div>
            </div>
          ) : null}

          <div className={`p-8 ${isLocked ? 'opacity-20 pointer-events-none blur-sm' : ''}`}>
            {activeTab === 'filtering' && (
              <div className="space-y-8">
                <div>
                  <h2 className="text-xl font-semibold text-slate-900 mb-4">Content Filtering Levels</h2>
                  <div className="space-y-6">
                    {/* Explicit Content */}
                    <div className="flex items-start justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div>
                        <h3 className="font-medium text-slate-900 flex items-center gap-2">
                          Explicit Nudity
                          <Lock className="w-4 h-4 text-slate-400" />
                        </h3>
                        <p className="text-sm text-slate-500 mt-1">Maximum bounding box blur. Cannot be disabled.</p>
                      </div>
                      <span className="px-3 py-1 bg-slate-200 text-slate-700 text-xs font-semibold rounded-full">Always On</span>
                    </div>

                    {/* Immodest Attire */}
                    <div className="flex items-start justify-between p-4 border border-slate-200 rounded-2xl">
                      <div className="pr-4">
                        <h3 className="font-medium text-slate-900">Immodest Attire (Soft-Porn)</h3>
                        <p className="text-sm text-slate-500 mt-1">Filters form-fitting clothing, exposed shoulders, and legs.</p>
                      </div>
                      <select 
                        value={settings.immodestAttire}
                        onChange={(e) => updateSetting('immodestAttire', e.target.value)}
                        className="bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-lg focus:ring-emerald-500 focus:border-emerald-500 block p-2.5"
                      >
                        <option>Strict (Recommended)</option>
                        <option>Moderate</option>
                        <option>Off</option>
                      </select>
                    </div>

                    {/* Unveiled Faces/Hair */}
                    <div className="flex items-start justify-between p-4 border border-slate-200 rounded-2xl">
                      <div className="pr-4">
                        <h3 className="font-medium text-slate-900">Unveiled Faces & Hair</h3>
                        <p className="text-sm text-slate-500 mt-1">Targeted blur to the head and neck region based on strictness.</p>
                      </div>
                      <select 
                        value={settings.unveiledFaces}
                        onChange={(e) => updateSetting('unveiledFaces', e.target.value)}
                        className="bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-lg focus:ring-emerald-500 focus:border-emerald-500 block p-2.5"
                      >
                        <option>Strict</option>
                        <option>Moderate</option>
                        <option>Off</option>
                      </select>
                    </div>

                    {/* Obfuscation Style */}
                    <div className="flex items-start justify-between p-4 border border-slate-200 rounded-2xl">
                      <div className="pr-4">
                        <h3 className="font-medium text-slate-900">Obfuscation Style</h3>
                        <p className="text-sm text-slate-500 mt-1">How the blocked content should appear on your screen.</p>
                      </div>
                      <select 
                        value={settings.obfuscationStyle}
                        onChange={(e) => updateSetting('obfuscationStyle', e.target.value)}
                        className="bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-lg focus:ring-emerald-500 focus:border-emerald-500 block p-2.5"
                      >
                        <option>Heavy Gaussian Blur</option>
                        <option>Solid Black Box</option>
                        <option>Pixelate</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="space-y-8">
                <div>
                  <h2 className="text-xl font-semibold text-slate-900 mb-4">Notification Preferences</h2>
                  <div className="space-y-4">
                    <label className="flex items-center justify-between p-4 border border-slate-200 rounded-2xl cursor-pointer hover:bg-slate-50 transition-colors">
                      <div>
                        <h3 className="font-medium text-slate-900">Real-time Block Alerts</h3>
                        <p className="text-sm text-slate-500 mt-1">Show a small toast notification when content is blurred.</p>
                      </div>
                      <div className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer" 
                          checked={settings.realTimeAlerts}
                          onChange={(e) => updateSetting('realTimeAlerts', e.target.checked)}
                        />
                        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                      </div>
                    </label>

                    <label className="flex items-center justify-between p-4 border border-slate-200 rounded-2xl cursor-pointer hover:bg-slate-50 transition-colors">
                      <div>
                        <h3 className="font-medium text-slate-900">Weekly Summary Report</h3>
                        <p className="text-sm text-slate-500 mt-1">Receive a weekly digest of blocked content statistics.</p>
                      </div>
                      <div className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer" 
                          checked={settings.weeklySummary}
                          onChange={(e) => updateSetting('weeklySummary', e.target.checked)}
                        />
                        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'accountability' && (
              <div className="space-y-8">
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <h2 className="text-xl font-semibold text-slate-900">Accountability Partner</h2>
                    <span className="px-2.5 py-0.5 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">Premium Feature</span>
                  </div>
                  <p className="text-sm text-slate-600 mb-6">
                    Add a trusted friend or family member. They will be notified if you attempt to disable the protection or uninstall the app.
                  </p>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Partner Name</label>
                      <input 
                        type="text" 
                        value={settings.partnerName}
                        onChange={(e) => updateSetting('partnerName', e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-xl focus:ring-emerald-500 focus:border-emerald-500 block p-3" 
                        placeholder="e.g. John Doe" 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Partner Email</label>
                      <input 
                        type="email" 
                        value={settings.partnerEmail}
                        onChange={(e) => updateSetting('partnerEmail', e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-xl focus:ring-emerald-500 focus:border-emerald-500 block p-3" 
                        placeholder="partner@example.com" 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Partner Phone (SMS Alerts)</label>
                      <div className="flex gap-2">
                        <input 
                          type="tel" 
                          value={settings.partnerPhone}
                          onChange={(e) => updateSetting('partnerPhone', e.target.value)}
                          className="flex-1 bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-xl focus:ring-emerald-500 focus:border-emerald-500 block p-3" 
                          placeholder="+1 234 567 890" 
                        />
                        <button
                          onClick={() => handleSendAlert('TEST_CONNECTION')}
                          disabled={isSendingAlert}
                          className="px-4 py-2 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-xl hover:bg-emerald-100 transition-colors disabled:opacity-50"
                        >
                          Test
                        </button>
                      </div>
                    </div>

                    <div className="pt-4">
                      <h3 className="text-sm font-medium text-slate-900 mb-3">Alert Triggers</h3>
                      <div className="space-y-2">
                        <label className="flex items-center gap-3">
                          <input 
                            type="checkbox" 
                            checked={settings.alertUninstall}
                            onChange={(e) => updateSetting('alertUninstall', e.target.checked)}
                            className="w-4 h-4 text-emerald-600 bg-slate-100 border-slate-300 rounded focus:ring-emerald-500" 
                          />
                          <span className="text-sm text-slate-700">App uninstallation attempt</span>
                        </label>
                        <label className="flex items-center gap-3">
                          <input 
                            type="checkbox" 
                            checked={settings.alertDisabled}
                            onChange={(e) => updateSetting('alertDisabled', e.target.checked)}
                            className="w-4 h-4 text-emerald-600 bg-slate-100 border-slate-300 rounded focus:ring-emerald-500" 
                          />
                          <span className="text-sm text-slate-700">VPN or Accessibility Service disabled</span>
                        </label>
                        <label className="flex items-center gap-3">
                          <input 
                            type="checkbox" 
                            checked={settings.alertHighFrequency}
                            onChange={(e) => updateSetting('alertHighFrequency', e.target.checked)}
                            className="w-4 h-4 text-emerald-600 bg-slate-100 border-slate-300 rounded focus:ring-emerald-500" 
                          />
                          <span className="text-sm text-slate-700">High frequency of explicit content detected</span>
                        </label>
                      </div>
                    </div>

                    <div className="pt-6 border-t border-slate-100">
                      <h3 className="text-sm font-medium text-slate-900 mb-3 flex items-center gap-2">
                        <Send className="w-4 h-4 text-emerald-600" />
                        Simulate Protection Events
                      </h3>
                      <p className="text-xs text-slate-500 mb-4">
                        Test your accountability integration by simulating protection breaches.
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <button
                          onClick={() => handleSendAlert('VPN_DISABLED')}
                          disabled={isSendingAlert}
                          className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-medium rounded-xl hover:bg-slate-200 transition-colors disabled:opacity-50"
                        >
                          VPN Disabled
                        </button>
                        <button
                          onClick={() => handleSendAlert('ACCESSIBILITY_DISABLED')}
                          disabled={isSendingAlert}
                          className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-medium rounded-xl hover:bg-slate-200 transition-colors disabled:opacity-50"
                        >
                          Accessibility Off
                        </button>
                        <button
                          onClick={() => handleSendAlert('UNINSTALL_ATTEMPT')}
                          disabled={isSendingAlert}
                          className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-medium rounded-xl hover:bg-slate-200 transition-colors disabled:opacity-50"
                        >
                          Uninstall Attempt
                        </button>
                      </div>
                      
                      {alertStatus && (
                        <div className="mt-4 p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-xs text-emerald-700 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4" />
                          {alertStatus}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="space-y-8">
                <div>
                  <h2 className="text-xl font-semibold text-slate-900 mb-4">Security & Anti-Bypass</h2>
                  
                  <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-6 flex gap-3">
                    <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-medium text-amber-800">Extreme Persistence Mode</h4>
                      <p className="text-sm text-amber-700 mt-1">Changes made here may require a device restart or 48-hour cooldown to reverse.</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-slate-200 rounded-2xl">
                      <div>
                        <h3 className="font-medium text-slate-900">Device Administrator</h3>
                        <p className="text-sm text-slate-500 mt-1">Prevents standard uninstallation.</p>
                      </div>
                      <button className="px-4 py-2 bg-slate-100 text-slate-700 text-sm font-medium rounded-lg hover:bg-slate-200 transition-colors">
                        Manage
                      </button>
                    </div>

                    <div className="flex items-center justify-between p-4 border border-slate-200 rounded-2xl">
                      <div>
                        <h3 className="font-medium text-slate-900">Uninstall Cooldown</h3>
                        <p className="text-sm text-slate-500 mt-1">Time required to wait before uninstalling.</p>
                      </div>
                      <select 
                        value={settings.uninstallCooldown}
                        onChange={(e) => updateSetting('uninstallCooldown', e.target.value)}
                        className="bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-lg focus:ring-emerald-500 focus:border-emerald-500 block p-2.5"
                      >
                        <option>24 Hours</option>
                        <option>48 Hours</option>
                        <option>7 Days</option>
                        <option>No Delay</option>
                      </select>
                    </div>

                    <div className="p-4 border border-slate-200 rounded-2xl">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="font-medium text-slate-900">Settings PIN Lock</h3>
                          <p className="text-sm text-slate-500 mt-1">Require a PIN to change any settings or disable protection.</p>
                        </div>
                        <div className="relative inline-flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            className="sr-only peer" 
                            checked={settings.requirePinForChanges}
                            onChange={(e) => updateSetting('requirePinForChanges', e.target.checked)}
                          />
                          <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                        </div>
                      </div>
                      {settings.requirePinForChanges && (
                        <div className="mt-4 pt-4 border-t border-slate-100">
                          <label className="block text-sm font-medium text-slate-700 mb-2">Set PIN Code</label>
                          <input 
                            type="password" 
                            maxLength={6}
                            placeholder="Enter 4-6 digit PIN"
                            value={settings.settingsPin}
                            onChange={(e) => updateSetting('settingsPin', e.target.value)}
                            className="bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-xl focus:ring-emerald-500 focus:border-emerald-500 block w-full p-3"
                          />
                        </div>
                      )}
                    </div>

                    <div className="p-4 border border-slate-200 rounded-2xl">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium text-slate-900">Safe Mode</h3>
                          <p className="text-sm text-slate-500 mt-1">Temporarily disable all filtering. Requires PIN.</p>
                          {isSafeModeActive && (
                            <p className="text-xs text-emerald-600 font-medium mt-2">
                              Active: {Math.ceil(((settings.safeModeEndTime || 0) - Date.now()) / 60000)} minutes remaining
                            </p>
                          )}
                        </div>
                        <button
                          onClick={toggleSafeMode}
                          className={`px-6 py-3 rounded-xl font-bold transition-colors ${
                            isSafeModeActive
                              ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                          }`}
                        >
                          {isSafeModeActive ? 'Safe Mode Active' : 'Enable Safe Mode'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {isSafeModePinPrompt && (
              <div className="absolute inset-0 z-20 bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center p-8">
                <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200 shadow-xl max-w-sm w-full text-center">
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Lock className="w-8 h-8" />
                  </div>
                  <h2 className="text-xl font-bold text-slate-900 mb-2">Enable Safe Mode</h2>
                  <p className="text-sm text-slate-500 mb-6">Enter your PIN to temporarily disable filtering.</p>
                  
                  <div className="space-y-4">
                    <input 
                      type="password" 
                      maxLength={6}
                      placeholder="Enter PIN"
                      value={safeModePinInput}
                      onChange={(e) => setSafeModePinInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSafeModeUnlock()}
                      className="bg-white border border-slate-200 text-slate-900 text-center text-lg tracking-widest rounded-xl focus:ring-emerald-500 focus:border-emerald-500 block w-full p-4"
                    />
                    {safeModePinError && <p className="text-red-500 text-sm">{safeModePinError}</p>}
                    <div className="flex gap-2">
                      <button
                        onClick={() => setIsSafeModePinPrompt(false)}
                        className="flex-1 bg-slate-200 text-slate-700 px-6 py-3 rounded-xl font-medium hover:bg-slate-300 transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleSafeModeUnlock}
                        className="flex-1 bg-emerald-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-emerald-700 transition-colors"
                      >
                        Unlock
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'dns' && (
              <div className="space-y-8">
                <div>
                  <h2 className="text-xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                    <Globe className="w-6 h-6 text-emerald-600" />
                    DNS & Network Filtering
                  </h2>
                  <p className="text-slate-600 mb-6">Manage network-level blocking and search engine restrictions.</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    <label className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-2xl cursor-pointer hover:bg-slate-100 transition-colors">
                      <div>
                        <h3 className="font-medium text-slate-900">Enforce SafeSearch</h3>
                        <p className="text-xs text-slate-500 mt-1">Forces strict SafeSearch on Google, Bing, and DuckDuckGo.</p>
                      </div>
                      <div className="relative inline-flex items-center cursor-pointer ml-4">
                        <input 
                          type="checkbox" 
                          className="sr-only peer" 
                          checked={settings.enforceSafeSearch}
                          onChange={(e) => updateSetting('enforceSafeSearch', e.target.checked)}
                        />
                        <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                      </div>
                    </label>

                    <label className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-2xl cursor-pointer hover:bg-slate-100 transition-colors">
                      <div>
                        <h3 className="font-medium text-slate-900">YouTube Restricted</h3>
                        <p className="text-xs text-slate-500 mt-1">Forces YouTube into Restricted Mode network-wide.</p>
                      </div>
                      <div className="relative inline-flex items-center cursor-pointer ml-4">
                        <input 
                          type="checkbox" 
                          className="sr-only peer" 
                          checked={settings.enforceYouTubeRestricted}
                          onChange={(e) => updateSetting('enforceYouTubeRestricted', e.target.checked)}
                        />
                        <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                      </div>
                    </label>
                  </div>

                  <h3 className="text-lg font-semibold text-slate-900 mb-4">Custom Blocklist</h3>
                  <div className="space-y-6">
                    {/* Add Domain */}
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        value={newDomain}
                        onChange={(e) => setNewDomain(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddDomain()}
                        placeholder="e.g. example.com"
                        className="flex-1 bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-xl focus:ring-emerald-500 focus:border-emerald-500 block p-3" 
                      />
                      <select
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value)}
                        className="bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-xl focus:ring-emerald-500 focus:border-emerald-500 block p-3 w-40"
                      >
                        <option value="Adult">Adult</option>
                        <option value="Gambling">Gambling</option>
                        <option value="Social Media">Social Media</option>
                        <option value="Malware">Malware</option>
                        <option value="Custom">Custom</option>
                      </select>
                      <button
                        onClick={handleAddDomain}
                        disabled={isAddingDomain || !newDomain.trim()}
                        className="bg-emerald-600 text-white px-6 py-3 rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors disabled:opacity-50 flex items-center gap-2"
                      >
                        {isAddingDomain ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                        Add Domain
                      </button>
                      <div className="relative">
                        <input
                          type="file"
                          accept=".txt"
                          onChange={handleFileUpload}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          disabled={isImporting}
                        />
                        <button
                          disabled={isImporting}
                          className="bg-slate-100 text-slate-700 px-4 py-3 rounded-xl text-sm font-medium hover:bg-slate-200 transition-colors disabled:opacity-50 flex items-center gap-2 border border-slate-200 h-full"
                        >
                          {isImporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                          Import .txt
                        </button>
                      </div>
                      <button
                        onClick={handleExportDomains}
                        disabled={blockedDomains.length === 0}
                        className="bg-slate-100 text-slate-700 px-4 py-3 rounded-xl text-sm font-medium hover:bg-slate-200 transition-colors disabled:opacity-50 flex items-center gap-2 border border-slate-200 h-full"
                      >
                        <Download className="w-4 h-4" />
                        Export .txt
                      </button>
                      <button
                        onClick={handleSyncRemote}
                        disabled={isSyncing}
                        className="bg-blue-50 text-blue-700 px-4 py-3 rounded-xl text-sm font-medium hover:bg-blue-100 transition-colors disabled:opacity-50 flex items-center gap-2 border border-blue-200 h-full"
                      >
                        {isSyncing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Globe className="w-4 h-4" />}
                        Sync Remote
                      </button>
                    </div>

                    {/* Domain List */}
                    <div className="bg-slate-50 rounded-2xl border border-slate-100 overflow-hidden">
                      <div className="max-h-[400px] overflow-y-auto">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-100/50">
                              <th 
                                className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:bg-slate-200/50 transition-colors"
                                onClick={() => handleSort('domain')}
                              >
                                Domain {sortConfig.key === 'domain' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                              </th>
                              <th 
                                className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:bg-slate-200/50 transition-colors"
                                onClick={() => handleSort('category')}
                              >
                                Category {sortConfig.key === 'category' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                              </th>
                              <th 
                                className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:bg-slate-200/50 transition-colors"
                                onClick={() => handleSort('added_at')}
                              >
                                Date Added {sortConfig.key === 'added_at' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                              </th>
                              <th className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Action</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200">
                            {sortedDomains.length === 0 ? (
                              <tr>
                                <td colSpan={4} className="p-8 text-center text-slate-400 text-sm italic">No domains blocked yet.</td>
                              </tr>
                            ) : (
                              sortedDomains.map((item) => (
                                <tr key={item.domain} className="hover:bg-white transition-colors">
                                  <td className="p-4 text-sm font-medium text-slate-900">{item.domain}</td>
                                  <td className="p-4">
                                    <span className={`px-3 py-1 text-[10px] font-bold rounded-full uppercase tracking-wider ${
                                      item.category === 'Adult' ? 'bg-red-100 text-red-700' :
                                      item.category === 'Gambling' ? 'bg-amber-100 text-amber-700' :
                                      item.category === 'Social Media' ? 'bg-blue-100 text-blue-700' :
                                      item.category === 'Malware' ? 'bg-purple-100 text-purple-700' :
                                      'bg-slate-100 text-slate-700'
                                    }`}>
                                      {item.category}
                                    </span>
                                  </td>
                                  <td className="p-4 text-sm text-slate-500">
                                    {parseDate(item.added_at)}
                                  </td>
                                  <td className="p-4 text-right">
                                    {item.category !== 'Adult' && (
                                      <button 
                                        onClick={() => handleDeleteDomain(item.domain)}
                                        className="p-2 text-slate-400 hover:text-red-600 transition-colors"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </button>
                                    )}
                                  </td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* URL Tester */}
                    <div className="mt-8 pt-8 border-t border-slate-200">
                      <h3 className="text-lg font-semibold text-slate-900 mb-4">Test URL Against Blocklist</h3>
                      <div className="flex gap-2 mb-4">
                        <input 
                          type="text" 
                          value={testUrl}
                          onChange={(e) => setTestUrl(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleTestUrl()}
                          placeholder="https://example.com/path"
                          className="flex-1 bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-xl focus:ring-emerald-500 focus:border-emerald-500 block p-3" 
                        />
                        <button
                          onClick={handleTestUrl}
                          className="bg-slate-900 text-white px-6 py-3 rounded-xl text-sm font-medium hover:bg-slate-800 transition-colors"
                        >
                          Test URL
                        </button>
                      </div>
                      {testResult && (
                        <div className={`p-4 rounded-xl border ${testResult.isBlocked ? 'bg-red-50 border-red-200 text-red-800' : 'bg-emerald-50 border-emerald-200 text-emerald-800'}`}>
                          <div className="flex items-center gap-2 font-semibold mb-1">
                            {testResult.isBlocked ? <AlertTriangle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
                            {testResult.isBlocked ? 'Access Denied' : 'Access Allowed'}
                          </div>
                          <p className="text-sm opacity-90">{testResult.message}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'apps' && (
              <div className="space-y-8">
                <div>
                  <h2 className="text-xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                    <Smartphone className="w-6 h-6 text-emerald-600" />
                    App Blocking & Limits
                  </h2>
                  <p className="text-slate-600 mb-6">Manage which applications can be opened on this device and set daily time limits.</p>

                  <div className="bg-slate-50 rounded-2xl border border-slate-100 overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-100/50">
                          <th className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Application</th>
                          <th className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Category</th>
                          <th className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Time Limit</th>
                          <th className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Usage</th>
                          <th className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {blockedApps.map((app) => (
                          <tr key={app.id} className="hover:bg-white transition-colors">
                            <td className="p-4">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-slate-200 rounded-xl flex items-center justify-center text-slate-500 font-bold">
                                  {app.name.charAt(0)}
                                </div>
                                <span className="text-sm font-medium text-slate-900">{app.name}</span>
                              </div>
                            </td>
                            <td className="p-4">
                              <span className="text-xs text-slate-500 bg-slate-100 px-2 py-1 rounded-md">
                                {app.category}
                              </span>
                            </td>
                            <td className="p-4">
                              <select 
                                value={app.timeLimit}
                                onChange={(e) => updateAppTimeLimit(app.id, e.target.value)}
                                disabled={app.isBlocked}
                                className="bg-slate-50 border border-slate-200 text-slate-900 text-xs rounded-lg focus:ring-emerald-500 focus:border-emerald-500 block p-2 disabled:opacity-50"
                              >
                                <option>None</option>
                                <option>15 Mins</option>
                                <option>30 Mins</option>
                                <option>1 Hour</option>
                                <option>2 Hours</option>
                              </select>
                            </td>
                            <td className="p-4 text-right">
                              <button
                                onClick={() => toggleAppBlock(app.id)}
                                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 ${
                                  app.isBlocked ? 'bg-red-500' : 'bg-slate-200'
                                }`}
                              >
                                <span
                                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                                    app.isBlocked ? 'translate-x-6' : 'translate-x-1'
                                  }`}
                                />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'intelligence' && (
              <div className="space-y-8">
                <div>
                  <h2 className="text-xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                    <Sparkles className="w-6 h-6 text-emerald-600" />
                    Safety Intelligence Agent
                  </h2>
                  <p className="text-slate-600 mb-6">Ask our AI agents about web safety, analyze potential threats, or generate safety-themed visuals.</p>

                  <div className="space-y-6">
                    {/* Input Area */}
                    <div className="relative">
                      <textarea
                        value={safetyQuery}
                        onChange={(e) => setSafetyQuery(e.target.value)}
                        placeholder="e.g. Is 'example-site.com' safe for children? or Describe the risks of social media addiction."
                        className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-2xl focus:ring-emerald-500 focus:border-emerald-500 block p-4 min-h-[120px]"
                      />
                      <div className="absolute bottom-3 right-3 flex gap-2">
                        <button
                          onClick={handleSafetyConsultant}
                          disabled={isAnalyzing || !safetyQuery}
                          className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-medium hover:bg-emerald-700 transition-colors disabled:opacity-50"
                        >
                          {isAnalyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                          Fast Advice
                        </button>
                        <button
                          onClick={handleDeepAnalysis}
                          disabled={isDeepAnalyzing || !safetyQuery}
                          className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl text-xs font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50"
                        >
                          {isDeepAnalyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Brain className="w-3 h-3" />}
                          Deep Audit
                        </button>
                      </div>
                    </div>

                    {/* Responses */}
                    {(safetyResponse || deepAnalysis) && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {safetyResponse && (
                          <div className="p-5 bg-emerald-50 border border-emerald-100 rounded-2xl">
                            <h4 className="text-xs font-bold text-emerald-800 uppercase tracking-wider mb-2 flex items-center gap-1">
                              <Sparkles className="w-3 h-3" />
                              Fast Consultant
                            </h4>
                            <p className="text-sm text-emerald-900 leading-relaxed whitespace-pre-wrap">{safetyResponse}</p>
                          </div>
                        )}
                        {deepAnalysis && (
                          <div className="p-5 bg-indigo-50 border border-indigo-100 rounded-2xl">
                            <h4 className="text-xs font-bold text-indigo-800 uppercase tracking-wider mb-2 flex items-center gap-1">
                              <Brain className="w-3 h-3" />
                              Deep Security Audit
                            </h4>
                            <p className="text-sm text-indigo-900 leading-relaxed whitespace-pre-wrap">{deepAnalysis}</p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Image Generation */}
                    <div className="pt-6 border-t border-slate-100">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-sm font-semibold text-slate-900">Safety Visual Generator</h3>
                          <p className="text-xs text-slate-500">Create custom protection-themed graphics with Nano Banana Pro.</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <select 
                            value={imageSize}
                            onChange={(e) => setImageSize(e.target.value as any)}
                            className="bg-slate-50 border border-slate-200 text-slate-900 text-xs rounded-lg p-1.5"
                          >
                            <option value="1K">1K</option>
                            <option value="2K">2K</option>
                            <option value="4K">4K</option>
                          </select>
                          <button
                            onClick={handleGenerateSafetyVisual}
                            disabled={isGeneratingImage}
                            className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-medium hover:bg-slate-800 transition-colors disabled:opacity-50"
                          >
                            {isGeneratingImage ? <Loader2 className="w-3 h-3 animate-spin" /> : <ImageIcon className="w-3 h-3" />}
                            Generate Graphic
                          </button>
                        </div>
                      </div>

                      <div className={`p-4 border rounded-xl mb-4 flex items-center justify-between ${hasKey ? 'bg-emerald-50 border-emerald-100' : 'bg-blue-50 border-blue-100'}`}>
                        <div className="flex items-center gap-2">
                          {hasKey ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertTriangle className="w-4 h-4 text-blue-600" />}
                          <p className={`text-xs ${hasKey ? 'text-emerald-700' : 'text-blue-700'}`}>
                            {hasKey ? 'Gemini API Key is configured.' : 'Image generation requires a paid Gemini API key.'}
                          </p>
                        </div>
                        <button 
                          onClick={handleOpenKeyDialog}
                          className={`text-xs font-bold underline ${hasKey ? 'text-emerald-800' : 'text-blue-800'}`}
                        >
                          {hasKey ? 'Change Key' : 'Select Key'}
                        </button>
                      </div>

                      {generatedImage && (
                        <div className="mt-4 rounded-2xl overflow-hidden border border-slate-200 shadow-lg aspect-square max-w-md mx-auto">
                          <img src={generatedImage} alt="Generated Safety Visual" className="w-full h-full object-cover" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'ai-models' && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-2">AI Models & Live Scanner</h2>
                  <p className="text-slate-500 text-sm mb-6">Manage on-device models and monitor real-time content analysis.</p>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Model Management */}
                    <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm">
                      <div className="flex items-center gap-3 mb-6">
                        <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                          <Brain className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-slate-900">On-Device Models</h3>
                          <p className="text-xs text-slate-500">Manage local AI filtering models.</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="p-4 rounded-2xl border border-slate-100 bg-slate-50 flex items-center justify-between">
                          <div>
                            <h4 className="text-sm font-semibold text-slate-900">Deep Vision Model ({modelStatus.version})</h4>
                            <p className="text-xs text-slate-500 mt-1">
                              {modelStatus.isUpdating ? modelStatus.updateMessage : (modelStatus.updateMessage || 'Up to date')}
                            </p>
                            {modelStatus.isUpdating && (
                              <div className="w-full h-1.5 bg-slate-200 rounded-full mt-2 overflow-hidden">
                                <div className="h-full bg-indigo-600 transition-all duration-300" style={{ width: `${modelStatus.progress}%` }} />
                              </div>
                            )}
                          </div>
                          <button
                            onClick={handleUpdateModel}
                            disabled={modelStatus.isUpdating}
                            className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-xs font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center gap-2"
                          >
                            {modelStatus.isUpdating ? <Loader2 className="w-3 h-3 animate-spin" /> : <Download className="w-3 h-3" />}
                            {modelStatus.isUpdating ? 'Updating...' : 'Update'}
                          </button>
                        </div>
                        <div className="p-4 rounded-2xl border border-slate-100 bg-slate-50 flex items-center justify-between">
                          <div>
                            <h4 className="text-sm font-semibold text-slate-900">Text Analysis Model (v1.8)</h4>
                            <p className="text-xs text-slate-500 mt-1">Status: Up to date</p>
                          </div>
                          <button
                            disabled
                            className="bg-slate-200 text-slate-500 px-4 py-2 rounded-xl text-xs font-medium disabled:opacity-50 flex items-center gap-2"
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            Latest
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Live Scanner Logs */}
                    <div className="bg-slate-900 rounded-3xl p-6 border border-slate-800 shadow-lg text-slate-300 flex flex-col h-[400px]">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-emerald-400">
                            <Activity className="w-5 h-5" />
                          </div>
                          <div>
                            <h3 className="text-lg font-semibold text-white">Live Scanner</h3>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="relative flex h-2 w-2">
                                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${liveScannerActive ? 'bg-emerald-400' : 'bg-slate-500'}`}></span>
                                <span className={`relative inline-flex rounded-full h-2 w-2 ${liveScannerActive ? 'bg-emerald-500' : 'bg-slate-600'}`}></span>
                              </span>
                              <p className="text-xs text-slate-400">{liveScannerActive ? 'Active & Monitoring' : 'Paused'}</p>
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => setLiveScannerActive(!liveScannerActive)}
                          className={`px-4 py-2 rounded-xl text-xs font-medium transition-colors ${liveScannerActive ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' : 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30'}`}
                        >
                          {liveScannerActive ? 'Pause Scanner' : 'Resume Scanner'}
                        </button>
                      </div>

                      <div className="flex-1 bg-black/50 rounded-2xl p-4 overflow-y-auto font-mono text-xs space-y-2 border border-slate-800">
                        {liveLogs.length === 0 ? (
                          <p className="text-slate-600 italic">Waiting for scanner activity...</p>
                        ) : (
                          liveLogs.map((log, index) => (
                            <div key={index} className="flex items-start gap-2">
                              <span className="text-slate-500 shrink-0">[{log.timestamp}]</span>
                              <span className={
                                log.level === 'info' ? 'text-blue-400' :
                                log.level === 'warn' ? 'text-orange-400' :
                                log.level === 'alert' ? 'text-red-400 font-bold' :
                                'text-slate-300'
                              }>
                                {log.message}
                              </span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Save Button */}
            <div className="mt-8 pt-6 border-t border-slate-100 flex justify-end">
              <button
                onClick={handleSave}
                className="flex items-center gap-2 bg-emerald-600 text-white px-6 py-2.5 rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors shadow-sm"
              >
                {saved ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    Saved
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save Changes
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}