package com.projectguardian.security

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * DEVICE OWNER MODE (Impenetrable Persistence)
 * 1. Handles Device Administrator privileges.
 * 2. If configured as Device Owner via ADB, this app cannot be uninstalled without a factory reset.
 */
class GuardianDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(context, "Project Guardian Device Admin Enabled", Toast.LENGTH_SHORT).show()
        // Lock down the device here (e.g., disable camera, enforce proxy)
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        // This message appears when the user tries to deactivate the Device Admin
        // The AccessibilityService (Unyielding Sentinel) should block them before they even see this
        return "Disabling Project Guardian will expose you to explicit content. Are you sure?"
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Toast.makeText(context, "Project Guardian Device Admin Disabled", Toast.LENGTH_SHORT).show()
        // Trigger Accountability Partner Alert
        sendAccountabilityAlert(context)
    }

    private fun sendAccountabilityAlert(context: Context) {
        // Logic to send SMS/Email to the accountability partner
        // "User has disabled Device Administrator privileges for Project Guardian."
    }
}
