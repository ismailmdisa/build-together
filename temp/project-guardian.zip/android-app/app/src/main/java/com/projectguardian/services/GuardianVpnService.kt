package com.projectguardian.services

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

class DomainTrieNode {
    val children = mutableMapOf<String, DomainTrieNode>()
    var isEndOfDomain = false
}

class DomainTrie {
    private val root = DomainTrieNode()

    fun insert(domain: String) {
        val parts = domain.lowercase().split(".").reversed()
        var current = root
        for (part in parts) {
            current = current.children.getOrPut(part) { DomainTrieNode() }
        }
        current.isEndOfDomain = true
    }

    fun matches(domain: String): Boolean {
        val parts = domain.lowercase().split(".").reversed()
        var current = root
        for (part in parts) {
            current = current.children[part] ?: return false
            if (current.isEndOfDomain) return true
        }
        return false
    }
}

class GuardianVpnService : VpnService(), Runnable {
    private var vpnThread: Thread? = null
    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (vpnThread == null) {
            vpnThread = Thread(this, "GuardianVpnThread")
            vpnThread?.start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        vpnThread?.interrupt()
        vpnInterface?.close()
        super.onDestroy()
    }

    private val blockedDomains = setOf(
        "explicit-content.com",
        "harmful-site.net",
        "malicious-example.org",
        "porn.com",
        "xxx.com",
        "adult-content.biz",
        "gambling-site.com",
        "betting-portal.net"
    )

    private val domainTrie = DomainTrie().apply {
        blockedDomains.forEach { insert(it) }
    }

    override fun run() {
        try {
            // Configure VPN interface
            val builder = Builder()
            builder.setSession("Project Guardian Network Shield")
            builder.addAddress("10.0.0.2", 32)
            builder.addRoute("0.0.0.0", 0)
            builder.addDnsServer("8.8.8.8") // Google DNS
            builder.addDnsServer("1.1.1.1") // Cloudflare DNS
            
            vpnInterface = builder.establish()
            
            val inputStream = FileInputStream(vpnInterface?.fileDescriptor)
            val outputStream = FileOutputStream(vpnInterface?.fileDescriptor)
            
            val packet = ByteBuffer.allocate(32767)
            
            while (!Thread.interrupted()) {
                val length = inputStream.read(packet.array())
                if (length > 0) {
                    packet.limit(length)
                    if (shouldBlockPacket(packet)) {
                        Log.i("GuardianVpn", "Blocked a request to a restricted domain")
                        sendNxDomainResponse(packet, outputStream)
                    } else {
                        outputStream.write(packet.array(), 0, length)
                    }
                }
                packet.clear()
            }
        } catch (e: Exception) {
            Log.e("GuardianVpn", "Error in VPN thread", e)
        } finally {
            vpnInterface?.close()
        }
    }

    private fun sendNxDomainResponse(requestPacket: ByteBuffer, outputStream: FileOutputStream) {
        try {
            val versionIhl = requestPacket.get(0).toInt()
            val ihl = (versionIhl and 0x0F) * 4
            val udpHeaderStart = ihl
            val dnsHeaderStart = udpHeaderStart + 8

            // Create response buffer
            val responseBuffer = ByteBuffer.allocate(requestPacket.limit())
            
            // 1. Copy IP Header and swap Source/Dest
            val ipHeader = ByteArray(ihl)
            requestPacket.position(0)
            requestPacket.get(ipHeader)
            
            // Swap IP addresses
            for (i in 0..3) {
                val temp = ipHeader[12 + i]
                ipHeader[12 + i] = ipHeader[16 + i]
                ipHeader[16 + i] = temp
            }
            responseBuffer.put(ipHeader)

            // 2. UDP Header
            val srcPort = ((requestPacket.get(udpHeaderStart).toInt() and 0xFF) shl 8) or (requestPacket.get(udpHeaderStart + 1).toInt() and 0xFF)
            val dstPort = ((requestPacket.get(udpHeaderStart + 2).toInt() and 0xFF) shl 8) or (requestPacket.get(udpHeaderStart + 3).toInt() and 0xFF)
            
            responseBuffer.putShort(dstPort.toShort()) // New Source is old Dest
            responseBuffer.putShort(srcPort.toShort()) // New Dest is old Source
            responseBuffer.putShort(requestPacket.getShort(udpHeaderStart + 4)) // Length (same for now)
            responseBuffer.putShort(0) // Checksum (optional for UDP)

            // 3. DNS Header
            val dnsId = requestPacket.getShort(dnsHeaderStart)
            responseBuffer.putShort(dnsId)
            // Flags: QR=1, Opcode=0, AA=1, TC=0, RD=1, RA=1, Z=0, RCODE=3 (NXDOMAIN)
            responseBuffer.putShort(0x8583.toShort()) 
            responseBuffer.putShort(requestPacket.getShort(dnsHeaderStart + 4)) // Questions
            responseBuffer.putShort(0) // Answer RRs
            responseBuffer.putShort(0) // Authority RRs
            responseBuffer.putShort(0) // Additional RRs

            // 4. Copy the rest of the DNS payload (Questions)
            val payloadLen = requestPacket.limit() - (dnsHeaderStart + 12)
            if (payloadLen > 0) {
                val payload = ByteArray(payloadLen)
                requestPacket.position(dnsHeaderStart + 12)
                requestPacket.get(payload)
                responseBuffer.put(payload)
            }

            // Update IP and UDP lengths
            val totalLen = responseBuffer.position()
            responseBuffer.putShort(2, totalLen.toShort()) // IP Total Length
            responseBuffer.putShort(ihl + 4, (totalLen - ihl).toShort()) // UDP Length

            outputStream.write(responseBuffer.array(), 0, totalLen)
        } catch (e: Exception) {
            Log.e("GuardianVpn", "Failed to send NXDOMAIN", e)
        }
    }

    private fun shouldBlockPacket(packet: ByteBuffer): Boolean {
        if (packet.limit() < 20) return false
        
        val versionIhl = packet.get(0).toInt()
        val version = (versionIhl shr 4) and 0x0F
        if (version != 4) return false

        val ihl = (versionIhl and 0x0F) * 4
        if (packet.limit() < ihl + 8) return false
        
        val protocol = packet.get(9).toInt()
        if (protocol != 17) return false // UDP

        val destPort = ((packet.get(ihl + 2).toInt() and 0xFF) shl 8) or (packet.get(ihl + 3).toInt() and 0xFF)
        
        if (destPort == 53) {
            val dnsHeaderStart = ihl + 8
            if (dnsHeaderStart + 12 <= packet.limit()) {
                val qdcount = packet.getShort(dnsHeaderStart + 4).toInt() and 0xFFFF
                var pos = dnsHeaderStart + 12
                
                for (i in 0 until qdcount) {
                    val result = parseDnsQuestion(packet, dnsHeaderStart, pos) ?: break
                    val domain = result.first
                    pos = result.second
                    
                    if (pos + 4 <= packet.limit()) {
                        val qtype = packet.getShort(pos).toInt() and 0xFFFF
                        val qclass = packet.getShort(pos + 2).toInt() and 0xFFFF
                        
                        // Handle standard DNS query types (A=1, AAAA=28, HTTPS=65, CNAME=5, etc.)
                        if (domainTrie.matches(domain)) {
                            return true
                        }
                        pos += 4
                    } else {
                        break
                    }
                }
            }
        }
        
        return false
    }

    private fun parseDnsQuestion(packet: ByteBuffer, dnsHeaderStart: Int, startPos: Int): Pair<String, Int>? {
        val domain = StringBuilder()
        var pos = startPos
        var jumped = false
        var maxJumps = 5
        var endPos = pos

        while (pos < packet.limit() && maxJumps > 0) {
            val labelLen = packet.get(pos).toInt() and 0xFF
            if (labelLen == 0) {
                if (!jumped) endPos = pos + 1
                break
            }

            if ((labelLen and 0xC0) == 0xC0) {
                if (!jumped) endPos = pos + 2
                if (pos + 1 >= packet.limit()) return null
                val offset = ((labelLen and 0x3F) shl 8) or (packet.get(pos + 1).toInt() and 0xFF)
                pos = dnsHeaderStart + offset
                jumped = true
                maxJumps--
            } else {
                pos++
                if (domain.isNotEmpty()) domain.append(".")
                for (i in 0 until labelLen) {
                    if (pos < packet.limit()) {
                        domain.append(packet.get(pos).toChar())
                        pos++
                    } else {
                        return null
                    }
                }
                if (!jumped) endPos = pos
            }
        }
        return Pair(domain.toString(), endPos)
    }
}
