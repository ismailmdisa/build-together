package com.projectguardian.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import com.projectguardian.R

/**
 * UI Lockdown Agent & Unyielding Sentinel
 * 1. Draws the blur/black overlay over inappropriate content.
 * 2. Blocks uninstallation by monitoring the Settings and Package Installer apps.
 */
class GuardianAccessibilityService : AccessibilityService() {

    companion object {
        private var instance: GuardianAccessibilityService? = null

        fun getInstance(): GuardianAccessibilityService? = instance
    }

    private var overlayView: View? = null
    private var isOverlayShowing = false

    private val blockReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (intent?.action == "com.projectguardian.ACTION_BLOCK_CONTENT") {
                showLockdownOverlay()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        
        android.util.Log.d("GuardianService", "Service Connected!")
        
        // Show a Toast so the user knows it's active
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            android.widget.Toast.makeText(this, "Guardian Shield Activated!", android.widget.Toast.LENGTH_LONG).show()
        }

        val filter = android.content.IntentFilter("com.projectguardian.ACTION_BLOCK_CONTENT")
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(blockReceiver, filter, android.content.Context.RECEIVER_NOT_EXPORTED)
        } else {
            androidx.core.content.ContextCompat.registerReceiver(
                this,
                blockReceiver,
                filter,
                androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
            )
        }
        
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or 
                         AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                         AccessibilityEvent.TYPE_VIEW_SCROLLED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or 
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            packageNames = null // Monitor all apps
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // UNYIELDING SENTINEL: Anti-Uninstall Protection
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            val packageName = event.packageName?.toString() ?: return
            val className = event.className?.toString() ?: ""
            val text = event.text?.toString() ?: ""
            
            // Log for debugging
            android.util.Log.d("GuardianService", "Event: type=${event.eventType}, pkg=$packageName, class=$className, text=$text")

            // Broaden the package check to include more system installers and settings
            val isSettingsOrInstaller = packageName.contains("settings", ignoreCase = true) ||
                    packageName.contains("installer", ignoreCase = true) ||
                    packageName.contains("package", ignoreCase = true) || // Added to catch more installers
                    packageName == "com.android.settings" || 
                    packageName == "com.google.android.packageinstaller" || 
                    packageName == "com.miui.securitycenter" || // Xiaomi
                    packageName == "com.samsung.android.lool" || // Samsung
                    packageName == "com.coloros.safecenter" || // Oppo/Realme
                    packageName == "com.sec.android.app.SecSetupWizard" || // Samsung setup
                    packageName == "com.android.vending" || // Google Play Store (uninstalling from there)
                    packageName == "com.sec.android.app.launcher" || // Samsung launcher (uninstalling from home screen)
                    packageName == "com.miui.home" || // Xiaomi launcher
                    packageName == "com.bbk.launcher2" || // Vivo launcher
                    packageName == "com.huawei.android.launcher" || // Huawei launcher
                    packageName == "com.oppo.launcher" || // Oppo launcher
                    packageName.contains("launcher", ignoreCase = true) // Catch any other launcher

            if (isSettingsOrInstaller) {
                android.util.Log.d("GuardianService", "Monitoring package: $packageName")
                // Check if the user is trying to access Device Admin, App Info, or Uninstall screens
                // We use a more aggressive text matching approach here
                val isUninstallAction = className.contains("DeviceAdmin") || 
                    className.contains("InstalledAppDetails") || 
                    className.contains("UninstallerActivity") ||
                    className.contains("app.AppInfoDashboardFragment") ||
                    text.contains("Uninstall", ignoreCase = true) ||
                    text.contains("Deactivate", ignoreCase = true) ||
                    text.contains("Device admin", ignoreCase = true) ||
                    text.contains("App info", ignoreCase = true) ||
                    text.contains("Application details", ignoreCase = true) ||
                    text.contains("Remove", ignoreCase = true) ||
                    text.contains("Delete", ignoreCase = true) ||
                    text.contains("Force stop", ignoreCase = true) ||
                    text.contains("Clear data", ignoreCase = true) ||
                    text.contains("Disable", ignoreCase = true)
                    
                // Also check the content description and text of the event source and its children
                var foundUninstallText = false
                val source = event.source
                if (source != null) {
                    val queue = java.util.LinkedList<android.view.accessibility.AccessibilityNodeInfo>()
                    queue.add(source)
                    while (queue.isNotEmpty()) {
                        val node = queue.poll()
                        if (node != null) {
                            val nodeText = node.text?.toString() ?: ""
                            val nodeDesc = node.contentDescription?.toString() ?: ""
                            if (nodeText.contains("Uninstall", ignoreCase = true) || 
                                nodeDesc.contains("Uninstall", ignoreCase = true) ||
                                nodeText.contains("Deactivate", ignoreCase = true) ||
                                nodeDesc.contains("Deactivate", ignoreCase = true) ||
                                nodeText.contains("Remove", ignoreCase = true) ||
                                nodeDesc.contains("Remove", ignoreCase = true) ||
                                nodeText.contains("Device admin", ignoreCase = true) ||
                                nodeDesc.contains("Device admin", ignoreCase = true) ||
                                nodeText.contains("Force stop", ignoreCase = true) ||
                                nodeDesc.contains("Force stop", ignoreCase = true) ||
                                nodeText.contains("Clear data", ignoreCase = true) ||
                                nodeDesc.contains("Clear data", ignoreCase = true) ||
                                nodeText.contains("Disable", ignoreCase = true) ||
                                nodeDesc.contains("Disable", ignoreCase = true)) {
                                foundUninstallText = true
                                break
                            }
                            for (i in 0 until node.childCount) {
                                val child = node.getChild(i)
                                if (child != null) queue.add(child)
                            }
                        }
                    }
                }

                if (isUninstallAction || foundUninstallText) {
                    android.util.Log.d("GuardianService", "Uninstall action detected! Triggering auth dialog.")
                    showLockdownOverlay() // Trigger custom confirmation dialog
                    // TODO: Trigger Accountability Partner Alert here
                }
            }
        }
    }

    /**
     * UI LOCKDOWN AGENT: Draws dynamic obfuscation overlays
     * Called by the Deep Vision Agent (TensorFlow Lite) when explicit content is detected.
     */
    fun drawObfuscationOverlay(boxes: List<com.projectguardian.ai.BoundingBox>) {
        // Run on main thread because we're touching UI
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            if (boxes.isEmpty()) {
                removeAllOverlays()
                return@post
            }

            // Sync overlay views with boxes
            while (overlayViews.size < boxes.size) {
                val newView = FrameLayout(this).apply {
                    setBackgroundColor(android.graphics.Color.BLACK) // Or Gaussian Blur
                }
                val params = WindowManager.LayoutParams(
                    1, 1,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                }
                windowManager.addView(newView, params)
                overlayViews.add(newView)
            }

            while (overlayViews.size > boxes.size) {
                val viewToRemove = overlayViews.removeAt(overlayViews.size - 1)
                windowManager.removeView(viewToRemove)
            }

            // Update positions and sizes
            for (i in boxes.indices) {
                val box = boxes[i]
                val view = overlayViews[i]
                val params = view.layoutParams as WindowManager.LayoutParams
                params.x = box.x
                params.y = box.y
                params.width = box.width
                params.height = box.height
                windowManager.updateViewLayout(view, params)
            }
        }
    }

    fun removeObfuscationOverlay() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            removeAllOverlays()
        }
    }

    private fun removeAllOverlays() {
        overlayViews.forEach { windowManager.removeView(it) }
        overlayViews.clear()
    }

    override fun onDestroy() {
        super.onDestroy()
        removeAllOverlays()
        removeLockdownOverlay()
        try {
            unregisterReceiver(blockReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        instance = null
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    private fun showLockdownOverlay() {
        if (isOverlayShowing) return

        try {
            val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
            overlayView = inflater.inflate(R.layout.overlay_lockdown, null)

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.CENTER

            // কীবোর্ড ঠিকমতো আসার জন্য এই লাইনটি খুব জরুরি
            params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

            val pinInput = overlayView?.findViewById<android.widget.EditText>(R.id.pinInput)
            val unlockBtn = overlayView?.findViewById<android.widget.Button>(R.id.unlockButton)

            unlockBtn?.setOnClickListener {
                val pin = pinInput?.text.toString()
                if (pin == "1234") {
                    // আনলক হলে কীবোর্ড নামিয়ে দেওয়া
                    val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                    imm.hideSoftInputFromWindow(pinInput?.windowToken, 0)

                    removeLockdownOverlay()
                } else {
                    android.widget.Toast.makeText(this, "Incorrect PIN!", android.widget.Toast.LENGTH_SHORT).show()
                }
            }

            windowManager?.addView(overlayView, params)
            isOverlayShowing = true

            // পিন বক্সে ফোকাস দিয়ে কীবোর্ড পপআপ করার চেষ্টা
            pinInput?.requestFocus()
            pinInput?.postDelayed({
                val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(pinInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }, 200)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeLockdownOverlay() {
        if (isOverlayShowing && overlayView != null) {
            try {
                windowManager?.removeView(overlayView)
                isOverlayShowing = false
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
