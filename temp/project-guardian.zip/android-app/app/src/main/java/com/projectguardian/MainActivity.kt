package com.projectguardian

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.projectguardian.security.GuardianDeviceAdminReceiver

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnScreenCapture = findViewById<Button>(R.id.btnScreenCapture)
        val btnAccessibility = findViewById<Button>(R.id.btnAccessibility)
        val btnDeviceAdmin = findViewById<Button>(R.id.btnDeviceAdmin)

        btnAccessibility.setOnClickListener {
            Toast.makeText(this, "Opening Settings...", Toast.LENGTH_SHORT).show()
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }

        btnScreenCapture.setOnClickListener {
            Toast.makeText(this, "Agent logic will be added soon!", Toast.LENGTH_SHORT).show()
        }
        
        btnDeviceAdmin.setOnClickListener {
            val componentName = ComponentName(this, GuardianDeviceAdminReceiver::class.java)
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName)
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Project Guardian requires Device Admin privileges to prevent unauthorized uninstallation.")
            }
            startActivityForResult(intent, 100)
        }
    }
}
